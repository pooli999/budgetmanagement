<?php
$DB = &JFactory::getDBO();

$Id = $_REQUEST["id"];

switch($_REQUEST["section"])
{
/*	case "setcounter":
		$sql = "UPDATE tblintra_edoc_center SET Count=Count+1 WHERE DocId='$Id' ";
		$DB->Execute($sql);
	break;
	
	case "checkin":
		$sql = "UPDATE tblintra_edoc_center SET CheckIn='Y' WHERE DocId='$Id' ";
		$DB->Execute($sql);
	break;
	case "checkout":
		$sql = "UPDATE tblintra_edoc_center SET CheckIn='N' WHERE DocId='$Id' ";
		$DB->Execute($sql);
	break;
*/}


exit();

?>